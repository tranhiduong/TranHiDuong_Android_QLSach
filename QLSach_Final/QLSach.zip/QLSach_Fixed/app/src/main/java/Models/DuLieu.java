package Models;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DuLieu {
    public static ArrayList<Sach> dsSach;
    static { dsSach=new ArrayList<>(); }
    public static ArrayList<LoaiSach> dsLoai;
    static {dsLoai=new ArrayList<>();}




}
